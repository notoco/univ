# -*- coding: utf-8 -*-
# Module: MSL
# Author: asciidisco
# Created on: 11.10.2017
# License: MIT https://goo.gl/5bMj3H

"""Tests for the `MSL` module"""

import unittest
import mock
from resources.lib.MSL import MSL

class MSLTestCase(unittest.TestCase):
    pass
